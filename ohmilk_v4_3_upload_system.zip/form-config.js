
window.formConfig = {
  products: [
    { name: "姓名貼", maxImages: 12, workingDays: 5 },
    { name: "底片鑰匙圈", maxImages: 60, workingDays: 3 },
    { name: "壓克力吊飾", maxImages: 20, workingDays: 4 }
  ]
};
